﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocketServer
{
    public enum SocketConnectionType
    {
        //服务端
        Server,

        //客户端
        Client
    }
}
